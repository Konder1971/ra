<template>
  <div class="content">
    <h1>Home Blog Page</h1>
    <hr>

    <transition-group
      name="list"
      tag="p"
    >
      <span
        v-for="item in items"
        :key="item"
        class="list-item"
      >{{ item }}</span>
    </transition-group>
    <button @click="add">
      Добавить
    </button>
    <button @click="remove">
      Удалить
    </button>
    <hr>

    <p>
      Перейти на сайт
      <a
        :href="urlGoogle"
        target="_blank"
      >Google</a>
      +
      <a
        href="https://google.com"
        class="googlelink"
        @click.prevent="isActive = !isActive"
        :class="blackWhait"
      >Запретили переход по ссылке - Кликай!</a>
    </p>
    <hr>

    <p v-if="isOk">
      Выводим Это если значение isOk = true
    </p>
    <hr>

    <p>
      <input
        type="text"
        v-model.lazy="inputValue"
      >
      <span>{{ inputValue }}</span>
    </p>
    <hr>

    <div v-html="vivodhtml" />
    <hr>
  </div>
</template>

<script>
export default {
  name: "Blogcontent",
  data() {
    return {
      items: [1, 2, 3, 4, 5, 6, 7, 8, 9],
      nextNum: 10,

      isOk: true,
      urlGoogle: "https://google.com",
      inputValue: "",
      isActive: false,
      vivodhtml: "<p>Это вывод <strong>html</strong></p>",
    };
  },
  methods: {
    randomIndex: function() {
      return Math.floor(Math.random() * this.items.length);
    },
    add: function() {
      this.items.splice(this.randomIndex(), 0, this.nextNum++);
    },
    remove: function() {
      this.items.splice(this.randomIndex(), 1);
    }
  },
  computed: {
    blackWhait: function() {
      return {
        black: this.isActive,
        whait: !this.isActive
      };
    }
  }
};
</script>

<style scoped>
hr {
  margin: 10px 0;
}
button {
  color: #fff;
  background-color: darkgreen;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  display: inline-block;
  padding: 10px 14px 12px;
  margin: 14px 10px 10px 0;
  font-size: 18px;
  font-weight: 600;
}
button:hover {
  background-color: #850000;
}

.list-item {
  display: inline-block;
  margin-right: 10px;
}
.list-enter-active,
.list-leave-active {
  transition: all 1s;
}
.list-enter, .list-leave-to /* .list-leave-active до версии 2.1.8 */ {
  opacity: 0;
  transform: translateY(30px);
}

.googlelink {
  color: #116149;
  font-size: 18px;
  text-decoration: none;
}
.black {
  color: #000;
}
.whait {
  color: #fff;
}

.t {
  display: flex;
  flex-direction: row;
  flex-wrap: nowrap;
  justify-content: center;
}
.circle,
.circle2 {
  width: 150px;
  height: 150px;
  margin: 0 auto;
  border-radius: 50%;
  border: 2px solid #ca092d;
  cursor: pointer;
}
.bc1 {
  background-color: #ca092d;
  border: 2px solid #000;
}
.bc2 {
  background-color: #2f68a1;
}
.bc3 {
  background-color: #07b717;
}
.bc4 {
  background-color: #35495e;
}
</style>
