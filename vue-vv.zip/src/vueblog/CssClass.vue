<template>
  <div class="content workwithClasses">
    <h1>Работа с классами</h1>
    <hr>

    <h4>Кликните на круг для изменения цвета заливки</h4>
    <div
      class="circle"
      @click="isActive = !isActive"
      :class="{ 'bc1' : isActive, 'bc2' : !isActive }"
    />
    <hr>
    <h4>Аналогичный вариант через computed</h4>
    <div
      class="circle"
      @click="isActive2 = !isActive2"
      :class="bkcolor"
    />

    <hr>


    <h4>
      Класс цвета: bc1 ; bc2 ; bc3
    </h4>
    <div>введи в поле класс цвета:</div>
    <input
      type="text"
      v-model="bgcolor"
    >
    <div
      class="circle"
      :class="bgcolor"
    />
  </div>
</template>

<script>
export default {
  name: 'Cssclass',
  data() {
    return {
      isActive: false,
      isActive2: false,
      bgcolor: ''
    }
  },

  computed: {
    bkcolor() {
      return {
				'bc4': this.isActive2,
				'bc3': !this.isActive2
			}
		}
  }

}
</script>

<style scoped>
  button {
    padding: 5px 10px;
  }
  hr {
    margin: 20px 0;
  }
  .circle,
  .circle2 {
    width: 150px;
    height: 150px;
    margin: 0 auto;
    border-radius: 50%;
    border: 2px solid #ca092d;
    cursor: pointer;
  }
  .bc1 {
    background-color: #850000;
    border: 2px solid #000;
  }
  .bc2 {
    background-color: #2f68a1;
  }
  .bc3 {
    background-color: #07b717;
  }
  .bc4 {
    background-color: #35495E,
  }
</style>
