<template>
  <div class="content replaceItems">
    <h2>Замена элементов</h2>

    <h3 v-if="isVisible">
      I am visible!
    </h3>
    <h3 v-else>
      No i am not!
    </h3>
    <button @click="isVisible = !isVisible">
      Кликнуть для смены заголовка
    </button>

    <hr>

    <div>
      <p>Выберите вариант отображения заголовка: a ; b ; c или другую букву</p>
      <h3 v-if="type === 'a'">
        variant A
      </h3>
      <h3 v-else-if="type === 'b'">
        variant B
      </h3>
      <h3 v-else-if="type === 'c'">
        variant C
      </h3>
      <h3 v-else>
        not math
      </h3>
      <input
        type="text"
        maxlength="1"
        v-model="type"
      >
    </div>

    <hr>

    <div>
      <p>Выбор варианта отображения template</p>
      <template v-if="isV1">
        <h3 style="color: green">
          Вариант 1 отображения template
        </h3>
        <p style="color: green">
          Lorem ipsum dolor sit amet consectetur adipisicing elit.
        </p>
      </template>
      <template v-else>
        <h3 style="color: red">
          Вариант 2 отображения template
        </h3>
        <p style="color: red">
          Lorem ipsum dolor sit amet consectetur adipisicing elit.
          Ullam voluptas earum ea tempore. Itaque incidunt quis quae praesentium aliquam laborum!
        </p>
      </template>
      <button @click="isV1 = !isV1">
        Кликнуть для смены отображения template
      </button>
    </div>

    <hr>

    <div>
      <h2>Деректива v-show</h2>
      <p>v-show - не удаляет элемент из DOM, а добавдяет display:none</p>
      <h3 v-show="vshowV1">
        Заголовок v-show 1
      </h3>
      <h3 v-show="!vshowV1">
        Заголовок v-show 2
      </h3>
      <button @click="vshowV1 = !vshowV1">
        Сменить заголовок v-show
      </button>
    </div>

    <hr>
  </div>
</template>

<script>
export default {
  name: 'ReplaceItems',
	data() {
		return {
			isV1: true,
      isVisible: true,
      type: '',
      vshowV1: true
    }
  }
}
</script>

<style scoped>
  button {
    padding: 5px 10px;
  }
  hr {
    margin: 20px 0;
  }
</style>
