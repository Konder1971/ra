<template>
  <nav>
    <nuxt-link exact no-prefetch to="/">
      Home
    </nuxt-link>
    <nuxt-link to="/todo">
      Todo
    </nuxt-link>
    <nuxt-link to="/about">
      About
    </nuxt-link>
    <nuxt-link to="/content/">
      Content
    </nuxt-link>
    <nuxt-link to="/technologies">
      Technologies
    </nuxt-link>
    <nuxt-link to="/nuxtblog/">
      Nuxtblog
    </nuxt-link>
  </nav>
</template>

<script>
export default {
  name: 'Navbar'
}
</script>

<style>
nav {
  background-color: #343a40;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  justify-content: center;
  align-items: center;
  align-content: center;
  padding: 10px;
}
nav a {
  font-weight: bold;
  color: rgba(255,255,255,.5);
  text-decoration: none;
  padding: 5px;
}
nav a:hover,
nav a.nuxt-link-exact-active {
  color:#fff;
  text-decoration: none;
}
</style>
