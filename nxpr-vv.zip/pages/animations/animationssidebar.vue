<template>
  <div class="animationssidebar">
    <h2>Sidebar</h2>
    <nuxt-link to="animations/shuffle">Перемешать</nuxt-link>
  </div>
</template>

<script>
export default {
}
</script>

<style scoped>
button {
  color: #fff;
  background-color: darkgreen;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  display: inline-block;
  padding: 6px 14px 8px;
  margin: 14px 10px 10px 0;
  font-size: 16px;
  font-weight: 600;
}
button:hover {
  background-color: #850000;
}
</style>
