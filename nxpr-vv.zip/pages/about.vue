<template>
  <nuxt />
</template>

<script>
export default {
  layout: 'containerfluid'
}
</script>

<style>
</style>
